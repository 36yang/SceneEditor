-----------------------------
About: Sinbad Character Model
-----------------------------

Artist: Zi Ye
Date: 2009-2010
E-mail: omniter@gmail.com

This work is licensed under the Creative Commons Attribution-Share Alike 3.0 Unported License.
To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or send a
letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

This character is a gift to the OGRE community (http://www.ogre3d.org).
You do not need to give credit to the artist, but it would be appreciated. =)

This license applies to the following files:
- Sinbad.mesh
- Sinbad.skeleton
- Sinbad.blend
- sinbad_body.tga
- sinbad_clothes.tga
- sinbad_sword.tga
- Sword.mesh
